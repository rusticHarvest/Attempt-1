import math
import os
import sys

def ErrorMsg():
    print("Error, Invalid input.")

def startingnew():
    os.execl(sys.executable, sys.executable, *sys.argv)
    
def exiting():
    os.execv

print("""+ : add
/ : divide
- : subtract
* : multiply
trig : Triginometry
sin : Sintax
cos : Cosine
^ : Square
squareroot : Squareroot
lnx : natural log function
e^x : exponential e function
startnew : Starting a new Operation
exit : Exiting Operation
""")

number1 = float(input("Enter the first number: "))
number2 = float(input("Enter the second number: "))
e = math.e
angle = float(input("Enter an angle if doing tan, sin, or cos: "))

operator = input("Enter an operator out of (+ - * / tan sin cos ^ squareroot lnx e^x): ")


if operator == "+":
    result = number1 + number2
    print(round(result,3))
elif operator == "-":
    result = number1 - number2
    print(round(result,3))
elif operator == "*":
    result = number1 * number2
    print(round(result,3))
elif operator == "/":
    result = number1 / number2
    print(round(result,3))
elif operator == "^":
    square = number1 * number1
elif operator == "sin":
    print(math.sin(angle))
elif operator == "tan":
    print(math.sin(angle))
elif operator == "cos":
    print(math.sin(angle))
elif operator == "lnx":
    print(math.log(number1))
elif operator == "e^x":
    print(math.exp(number1))
else:
    ErrorMsg()

operator = input("Enter an operator out of (startnew exit): ")

if operator == "startnew":
    startingnew()
elif operator == "exit":
    exiting()
